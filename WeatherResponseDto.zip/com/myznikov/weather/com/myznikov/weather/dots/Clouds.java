
package com.myznikov.weather.com.myznikov.weather.dots;

import java.util.List;

public class Clouds{
   	private Number all;

 	public Number getAll(){
		return this.all;
	}
	public void setAll(Number all){
		this.all = all;
	}
}
