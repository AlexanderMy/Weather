
package com.myznikov.weather.com.myznikov.weather.dots;

import java.util.List;

public class Wind{
   	private Number deg;
   	private Number speed;

 	public Number getDeg(){
		return this.deg;
	}
	public void setDeg(Number deg){
		this.deg = deg;
	}
 	public Number getSpeed(){
		return this.speed;
	}
	public void setSpeed(Number speed){
		this.speed = speed;
	}
}
